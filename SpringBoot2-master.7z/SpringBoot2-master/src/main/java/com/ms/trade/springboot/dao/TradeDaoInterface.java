package com.ms.trade.springboot.dao;

import java.util.List;

import com.ms.trade.springboot.beans.Trades;

public interface TradeDaoInterface {

	List<Trades> tradesForBroker(String brokerCode);

	List<Trades> getTopTrade(String buySellIndicator);

	int insert(Trades trade);

	Integer getCount(String tradeId);

}