package com.ms.trade.springboot.dao;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.ms.trade.springboot.beans.Trades;
import com.ms.trade.springboot.tradesApp.TradesAppApplication;

@Repository
public class TradesDao implements TradeDaoInterface {
	@Autowired
	JdbcTemplate jdbcTemplate;

	
	@Override
	public List<Trades> tradesForBroker(String brokerCode) {
		return jdbcTemplate.query("select * from trade where brokerCode = ?", new Object[] { brokerCode },
				new BeanPropertyRowMapper(Trades.class));

	}

	@Override
	public List<Trades> getTopTrade(String buySellIndicator) {
		jdbcTemplate.setMaxRows(5);
		return jdbcTemplate.query("select * from trade where buySellIndicator = ? order by quantity desc",
				new Object[] { buySellIndicator }, new BeanPropertyRowMapper(Trades.class));
		
	}
	
	@Override
	public  Integer getCount(String tradeId){
		
		return jdbcTemplate.queryForObject(" select count(*) from trade where tradeId =?", new Object[]{tradeId}, Integer.class);
		  
	}

	@Override
	public int insert(Trades trade) {
		return jdbcTemplate.update(
				" insert into trade (tradeId,stockName,brokerCode,brokerName,quantity,tradeDate,settlementDate,buySellIndicator) "
						+ " values(?,?,?,?,?,?,?,?)",
				new Object[] { trade.getTradeId(), trade.getStockName(), trade.getBrokerCode(), trade.getBrokerName(),
						trade.getQuantity(), trade.getTradeDate(), trade.getSettlementDate(),
						trade.getBuySellIndicator() });

	}
}
