package com.ms.trade.springboot.beans;

public enum BuySellIndicator {
    B, S;
}