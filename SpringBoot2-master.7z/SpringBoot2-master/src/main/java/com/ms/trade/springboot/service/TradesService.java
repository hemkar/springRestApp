package com.ms.trade.springboot.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ms.trade.springboot.beans.Trades;
import com.ms.trade.springboot.dao.TradeDaoInterface;

@Service
public class TradesService implements TradesServiceInterface {
	private static final Logger logger = LoggerFactory.getLogger(TradesService.class);
	@Autowired
	TradeDaoInterface tradesDao;
	
	@Override
	public List<Trades> getTradesForBroker(String brokerId){
		
		return tradesDao.tradesForBroker(brokerId);
	}

	@Override
	public List<Trades> getTopTrade(String buySellIndicator) {
		return tradesDao.getTopTrade(buySellIndicator);
	}

	@Override
	public void insert(Trades trade) {
		Integer i=getCount(trade.getTradeId());
		if(i>0){
			logger.error("Duplicate : {}", trade);
		}else{
		tradesDao.insert(trade);
		}
	}
	
	@Override
	public Integer getCount(String tradeId){
		return tradesDao.getCount(tradeId);
	}
	
}
